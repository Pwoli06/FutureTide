import { useMemo, useState } from "react";
import OceanScene from "./components/OceanScene";
import { Segmented } from "./components/Segmented";
import { Stats } from "./components/Stats";
import { TrajectoryChart } from "./components/TrajectoryChart";
import "./App.css";
import {
  FORECAST_PATHWAYS,
  FORECAST_YEARS,
  compareScenarios,
  file,
  formatDelta,
  formatNumber,
  pathwayLabel,
  resolveSelection,
  scenarioTitle,
  type ForecastPathway,
  type SlotSelection,
} from "./lib/scenarios.ts";

const DEFAULT_SLOT_A: SlotSelection = { pathway: "reducing", year: 2100, baseline: false };
const DEFAULT_SLOT_B: SlotSelection = { pathway: "increasing", year: 2100, baseline: false };

function Pickers({
  selection,
  onChange,
}: {
  selection: SlotSelection;
  onChange: (next: SlotSelection) => void;
}) {
  const pathwayValue = selection.baseline ? null : selection.pathway;
  const yearValue = selection.baseline ? null : String(selection.year);

  return (
    <div className="pickers">
      {selection.baseline ? <p className="pickers__note">Showing the 2025 baseline</p> : null}
      <Segmented
        label="Pathway"
        value={pathwayValue}
        options={FORECAST_PATHWAYS.map((id) => ({
          id,
          label: pathwayLabel(id),
          hint: file.pathways[id],
        }))}
        onChange={(id) =>
          onChange({
            pathway: id as ForecastPathway,
            year: selection.year,
            baseline: false,
          })
        }
      />
      <Segmented
        label="Year"
        value={yearValue}
        options={FORECAST_YEARS.map((year) => ({ id: String(year), label: String(year) }))}
        onChange={(id) =>
          onChange({
            pathway: selection.pathway,
            year: Number(id),
            baseline: false,
          })
        }
      />
    </div>
  );
}

function Narrative({ scenario }: { scenario: ReturnType<typeof resolveSelection> }) {
  return (
    <div className="narrative">
      <div className="narrative__top">
        <h2>{scenario.headline}</h2>
        <span className={`badge badge--${scenario.confidence}`}>{scenario.confidence} confidence</span>
      </div>
      <p>{scenario.explanation}</p>
      <ul className="chips">
        {scenario.keyDrivers.map((driver) => (
          <li key={driver}>{driver}</li>
        ))}
      </ul>
    </div>
  );
}

function Disclaimer() {
  return (
    <aside className="disclaimer">
      <p>{file.disclaimer}</p>
      <details>
        <summary>Sources</summary>
        <ul>
          {file.sources.map((source) => (
            <li key={source}>{source}</li>
          ))}
        </ul>
      </details>
    </aside>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <p>Scenario data generated with Grok · Extends BDBI FishCast</p>
    </footer>
  );
}

export function App() {
  const [pathway, setPathway] = useState<ForecastPathway>("maintaining");
  const [year, setYear] = useState(2050);
  const [compare, setCompare] = useState(false);
  const [slotA, setSlotA] = useState<SlotSelection>(DEFAULT_SLOT_A);
  const [slotB, setSlotB] = useState<SlotSelection>(DEFAULT_SLOT_B);

  const single = resolveSelection({ pathway, year, baseline: false });
  const futureA = resolveSelection(slotA);
  const futureB = resolveSelection(slotB);
  const rows = useMemo(() => compareScenarios(futureA, futureB), [futureA, futureB]);

  const chartActive: ForecastPathway[] = compare
    ? [slotA.baseline ? null : slotA.pathway, slotB.baseline ? null : slotB.pathway].filter(
        (id): id is ForecastPathway => id !== null,
      )
    : [pathway];

  return (
    <div className="app">
      <header className="header">
        <div className="brand">
          <svg className="brand__mark" viewBox="0 0 32 32" aria-hidden="true">
            <path
              d="M4 14c3.2 0 3.2-5 7.2-5s4 5 7.2 5 4-5 7.2-5"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
            />
            <path
              d="M4 22c3.2 0 3.2-4 7.2-4s4 4 7.2 4 4-4 7.2-4"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.8"
              strokeLinecap="round"
              opacity="0.55"
            />
          </svg>
          <div>
            <p className="brand__name">FutureTide</p>
            <p className="brand__sub">{file.region}</p>
          </div>
        </div>
        <button
          type="button"
          className={compare ? "compare-toggle is-on" : "compare-toggle"}
          aria-pressed={compare}
          onClick={() => setCompare((value) => !value)}
        >
          Compare futures
        </button>
      </header>

      <Disclaimer />

      <main className="main">
        {compare ? (
          <div className="compare">
            <div className="presets">
              <button
                type="button"
                onClick={() => {
                  setSlotA(DEFAULT_SLOT_A);
                  setSlotB(DEFAULT_SLOT_B);
                }}
              >
                Best vs worst 2100
              </button>
              <button
                type="button"
                onClick={() => {
                  setSlotA({ pathway: "reducing", year: 2100, baseline: true });
                  setSlotB(DEFAULT_SLOT_B);
                }}
              >
                Today vs worst 2100
              </button>
            </div>
            <div className="compare__cols">
              {(["A", "B"] as const).map((name) => {
                const selection = name === "A" ? slotA : slotB;
                const scenario = name === "A" ? futureA : futureB;
                const setSelection = name === "A" ? setSlotA : setSlotB;
                return (
                  <section key={name} className="column" aria-label={`Future ${name}`}>
                    <p className="column__tag">
                      {name}
                      <span>{scenarioTitle(scenario)}</span>
                    </p>
                    <Pickers selection={selection} onChange={setSelection} />
                    <div className="stage stage--compare">
                      <OceanScene scenario={scenario} />
                    </div>
                    <Stats scenario={scenario} compact />
                  </section>
                );
              })}
            </div>

            <div className="table-wrap">
              <table className="diff">
                <caption>
                  {scenarioTitle(futureA)} against {scenarioTitle(futureB)}. The healthier value is marked on each row.
                </caption>
                <thead>
                  <tr>
                    <th scope="col">Metric</th>
                    <th scope="col">A</th>
                    <th scope="col">B</th>
                    <th scope="col">B − A</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((row) => (
                    <tr key={row.key}>
                      <th scope="row">
                        {row.label}
                        <span>{row.unit}</span>
                      </th>
                      <td className={row.winner === "a" ? "is-healthier" : undefined}>
                        {formatNumber(row.a, row.decimals)}
                        {row.winner === "a" ? <em>Healthier</em> : null}
                      </td>
                      <td className={row.winner === "b" ? "is-healthier" : undefined}>
                        {formatNumber(row.b, row.decimals)}
                        {row.winner === "b" ? <em>Healthier</em> : null}
                      </td>
                      <td className={row.winner === "tie" ? "is-tie" : row.winner === "b" ? "is-b" : "is-a"}>
                        {formatDelta(row.difference, row.decimals)}
                        <em>{row.winner === "tie" ? "Even" : row.winner === "a" ? "A healthier" : "B healthier"}</em>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <TrajectoryChart active={chartActive} />
          </div>
        ) : (
          <div className="workspace">
            <div className="stage">
              <OceanScene scenario={single} />
            </div>
            <aside className="panel">
              <Pickers
                selection={{ pathway, year, baseline: false }}
                onChange={(next) => {
                  setPathway(next.pathway);
                  setYear(next.year);
                }}
              />
              <Narrative scenario={single} />
              <Stats scenario={single} />
              <TrajectoryChart active={chartActive} />
            </aside>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
