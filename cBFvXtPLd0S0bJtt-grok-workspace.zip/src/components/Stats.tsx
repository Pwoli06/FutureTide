import type { Scenario } from "../../data/schema.ts";
import {
  changesVsBaseline,
  formatDelta,
  formatNumber,
  stressColor,
  type MetricChange,
} from "../lib/scenarios.ts";
import { useTween } from "../lib/useTween.ts";

function TweenNum({ value, decimals }: { value: number; decimals: number }) {
  const shown = useTween(value);
  return <>{formatNumber(shown, decimals)}</>;
}

function Delta({ change }: { change: MetricChange }) {
  const tone = change.worse ? "worse" : change.better ? "better" : "flat";
  const arrow = change.delta > 0 ? "↑" : change.delta < 0 ? "↓" : "–";
  return (
    <span className={`delta delta--${tone}`}>
      <span aria-hidden="true">{arrow}</span> {formatDelta(change.delta, change.decimals)}
      <span className="delta__vs"> vs 2025</span>
    </span>
  );
}

export function Stats({ scenario, compact = false }: { scenario: Scenario; compact?: boolean }) {
  const changes = changesVsBaseline(scenario);
  const primary = changes.filter((change) => change.group === "primary");
  const stress = changes.find((change) => change.key === "ecosystemStress");
  const predators = changes.filter((change) => change.group === "predator");
  if (!stress) return null;

  return (
    <div className={compact ? "stats stats--compact" : "stats"}>
      <div className="stats__grid">
        {primary.map((change) => (
          <article key={change.key} className="stat">
            <h3>{change.label}</h3>
            <p className="stat__value">
              <TweenNum value={change.value} decimals={change.decimals} />
              <span>{change.unit}</span>
            </p>
            <Delta change={change} />
          </article>
        ))}
      </div>

      <article className="stat stat--stress">
        <div className="stat__row">
          <h3>Ecosystem stress</h3>
          <p className="stat__value">
            <TweenNum value={stress.value} decimals={0} />
            <span>/ 100</span>
          </p>
        </div>
        <div
          className="bar"
          role="meter"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={stress.value}
          aria-label="Ecosystem stress"
        >
          <div
            className="bar__fill"
            style={{ width: `${Math.max(0, Math.min(100, stress.value))}%`, background: stressColor(stress.value) }}
          />
        </div>
        <Delta change={stress} />
      </article>

      <article className="stat stat--predators">
        <h3>Predator health</h3>
        <ul>
          {predators.map((change) => (
            <li key={change.key}>
              <div className="stat__row">
                <span>{change.label}</span>
                <span className="stat__mini">
                  <TweenNum value={change.value} decimals={0} />
                  <Delta change={change} />
                </span>
              </div>
              <div
                className="bar bar--mini"
                role="meter"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={change.value}
                aria-label={`${change.label} health`}
              >
                <div
                  className="bar__fill"
                  style={{
                    width: `${Math.max(0, Math.min(100, change.value))}%`,
                    background: stressColor(100 - change.value),
                  }}
                />
              </div>
            </li>
          ))}
        </ul>
      </article>
    </div>
  );
}
