import type { Scenario } from "../../data/schema.ts";

function labelize(key: string): string {
  const spaced = key.replace(/([A-Z])/g, " $1");
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

function formatVisual(value: unknown): string {
  if (typeof value === "number") return value.toFixed(2);
  return String(value);
}

/** Placeholder water body. Replace this file; keep the default-export signature. */
export default function OceanScene({ scenario }: { scenario: Scenario }) {
  const visual = scenario.visual;
  const dim = Math.min(1, Math.max(0, visual.waterTurbidity));

  return (
    <div className="ocean-scene" style={{ backgroundColor: visual.waterTint }}>
      <div className="ocean-scene__dim" style={{ opacity: dim }} />
      <div className="ocean-scene__readout">
        <p className="ocean-scene__kicker">Visual state</p>
        <dl>
          {Object.entries(visual).map(([key, value]) => (
            <div key={key}>
              <dt>{labelize(key)}</dt>
              <dd>{formatVisual(value)}</dd>
            </div>
          ))}
        </dl>
      </div>
    </div>
  );
}
