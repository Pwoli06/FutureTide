import { useId } from "react";

export interface SegmentOption {
  id: string;
  label: string;
  hint?: string;
}

export function Segmented({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string | null;
  options: SegmentOption[];
  onChange: (id: string) => void;
}) {
  const labelId = useId();

  return (
    <div className="seg">
      <span className="seg__label" id={labelId}>
        {label}
      </span>
      <div className="seg__group" role="radiogroup" aria-labelledby={labelId}>
        {options.map((option) => {
          const selected = option.id === value;
          return (
            <button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={selected}
              className={selected ? "seg__btn is-selected" : "seg__btn"}
              onClick={() => onChange(option.id)}
            >
              <span>{option.label}</span>
              {option.hint ? <small>{option.hint}</small> : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}
