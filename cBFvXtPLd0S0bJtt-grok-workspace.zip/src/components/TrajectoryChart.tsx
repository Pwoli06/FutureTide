import {
  FORECAST_PATHWAYS,
  PATHWAY_COLORS,
  file,
  pathwayLabel,
  stressTrajectory,
  type ForecastPathway,
} from "../lib/scenarios.ts";

const YEARS = [file.baseline.year, ...file.years];
const WIDTH = 360;
const HEIGHT = 168;
const PAD_L = 32;
const PAD_R = 8;
const PAD_T = 12;
const PAD_B = 26;

function xFor(year: number): number {
  return PAD_L + ((year - 2025) / 75) * (WIDTH - PAD_L - PAD_R);
}

function yFor(stress: number): number {
  return PAD_T + (1 - stress / 100) * (HEIGHT - PAD_T - PAD_B);
}

export function TrajectoryChart({ active }: { active: ForecastPathway[] }) {
  return (
    <figure className="chart">
      <figcaption>
        <span>Ecosystem stress</span>
        <span>Shared 2025 start</span>
      </figcaption>
      <svg viewBox={`0 0 ${WIDTH} ${HEIGHT}`} role="img" aria-label="Ecosystem stress from 2025 to 2100 for three pathways">
        {[0, 50, 100].map((tick) => (
          <g key={tick}>
            <line className="chart__grid" x1={PAD_L} x2={WIDTH - PAD_R} y1={yFor(tick)} y2={yFor(tick)} />
            <text className="chart__tick" x={PAD_L - 6} y={yFor(tick) + 3} textAnchor="end">
              {tick}
            </text>
          </g>
        ))}
        {FORECAST_PATHWAYS.map((pathway) => {
          const on = active.includes(pathway);
          const points = stressTrajectory(pathway)
            .map((point) => `${xFor(point.year)},${yFor(point.stress)}`)
            .join(" ");
          return (
            <g key={pathway}>
              <polyline
                points={points}
                fill="none"
                stroke={PATHWAY_COLORS[pathway]}
                strokeWidth={on ? 2.6 : 1.4}
                strokeLinejoin="round"
                strokeLinecap="round"
                opacity={on ? 1 : 0.38}
              />
              {stressTrajectory(pathway).map((point) => (
                <circle
                  key={point.year}
                  cx={xFor(point.year)}
                  cy={yFor(point.stress)}
                  r={on ? 3.2 : 2}
                  fill={PATHWAY_COLORS[pathway]}
                  opacity={on ? 1 : 0.45}
                >
                  <title>{`${pathwayLabel(pathway)} ${point.year}: ${point.stress}`}</title>
                </circle>
              ))}
            </g>
          );
        })}
        {YEARS.map((year) => (
          <text key={year} className="chart__tick" x={xFor(year)} y={HEIGHT - 6} textAnchor="middle">
            {year}
          </text>
        ))}
      </svg>
      <ul className="chart__legend">
        {FORECAST_PATHWAYS.map((pathway) => (
          <li key={pathway} className={active.includes(pathway) ? "is-active" : undefined}>
            <i style={{ background: PATHWAY_COLORS[pathway] }} />
            {pathwayLabel(pathway)}
          </li>
        ))}
      </ul>
    </figure>
  );
}
