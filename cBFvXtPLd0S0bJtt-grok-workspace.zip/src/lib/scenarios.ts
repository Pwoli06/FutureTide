import raw from "../../data/scenarios.json";
import type { Pathway, Scenario, ScenarioFile } from "../../data/schema.ts";

export type { Pathway, Scenario, ScenarioFile };

export type ForecastPathway = Exclude<Pathway, "baseline">;

export const file = raw as ScenarioFile;

export const baseline: Scenario = file.baseline;

export const FORECAST_YEARS: readonly number[] = file.years;

export const FORECAST_PATHWAYS: readonly ForecastPathway[] = ["reducing", "maintaining", "increasing"];

export function getScenario(pathway: ForecastPathway, year: number): Scenario {
  const found = file.scenarios.find((scenario) => scenario.pathway === pathway && scenario.year === year);
  if (!found) {
    throw new Error(`No scenario for ${pathway} ${year}`);
  }
  return found;
}

export type SlotSelection = {
  pathway: ForecastPathway;
  year: number;
  /** When true, the slot shows the 2025 baseline instead of pathway/year. */
  baseline: boolean;
};

export function resolveSelection(selection: SlotSelection): Scenario {
  if (selection.baseline) return baseline;
  return getScenario(selection.pathway, selection.year);
}

export function scenarioTitle(scenario: Scenario): string {
  if (scenario.pathway === "baseline") return "Today · 2025";
  const label = scenario.pathway.charAt(0).toUpperCase() + scenario.pathway.slice(1);
  return `${label} · ${scenario.year}`;
}

export function pathwayLabel(pathway: ForecastPathway): string {
  return pathway.charAt(0).toUpperCase() + pathway.slice(1);
}

export type MetricKey =
  | "sstAnomalyC"
  | "seaIceExtentPctOfToday"
  | "krillDensityPctOfToday"
  | "krillOutsideMpaPct"
  | "ecosystemStress"
  | "penguins"
  | "whales"
  | "seals";

export interface MetricChange {
  key: MetricKey;
  label: string;
  unit: string;
  group: "primary" | "predator" | "stress";
  decimals: number;
  value: number;
  baseline: number;
  delta: number;
  higherIsWorse: boolean;
  worse: boolean;
  better: boolean;
}

const METRIC_SPEC: Record<
  MetricKey,
  {
    label: string;
    unit: string;
    group: MetricChange["group"];
    decimals: number;
    higherIsWorse: boolean;
  }
> = {
  sstAnomalyC: { label: "SST anomaly", unit: "°C", group: "primary", decimals: 2, higherIsWorse: true },
  seaIceExtentPctOfToday: {
    label: "Sea ice",
    unit: "% of today",
    group: "primary",
    decimals: 0,
    higherIsWorse: false,
  },
  krillDensityPctOfToday: {
    label: "Krill density",
    unit: "% of today",
    group: "primary",
    decimals: 0,
    higherIsWorse: false,
  },
  krillOutsideMpaPct: {
    label: "Hotspots outside MPAs",
    unit: "%",
    group: "primary",
    decimals: 0,
    higherIsWorse: true,
  },
  ecosystemStress: { label: "Ecosystem stress", unit: "0–100", group: "stress", decimals: 0, higherIsWorse: true },
  penguins: { label: "Penguins", unit: "health", group: "predator", decimals: 0, higherIsWorse: false },
  whales: { label: "Whales", unit: "health", group: "predator", decimals: 0, higherIsWorse: false },
  seals: { label: "Seals", unit: "health", group: "predator", decimals: 0, higherIsWorse: false },
};

function roundTo(value: number, decimals: number): number {
  const factor = 10 ** decimals;
  return Math.round(value * factor) / factor;
}

function readMetric(scenario: Scenario, key: MetricKey): number {
  if (key === "penguins" || key === "whales" || key === "seals") {
    return scenario.predatorHealth[key];
  }
  return scenario[key];
}

/** Each metric's change versus the 2025 baseline. Positive delta means the value rose. */
export function changesVsBaseline(scenario: Scenario): MetricChange[] {
  return (Object.keys(METRIC_SPEC) as MetricKey[]).map((key) => {
    const spec = METRIC_SPEC[key];
    const value = roundTo(readMetric(scenario, key), spec.decimals);
    const base = roundTo(readMetric(baseline, key), spec.decimals);
    const delta = roundTo(value - base, spec.decimals);
    const worse = spec.higherIsWorse ? delta > 0 : delta < 0;
    const better = spec.higherIsWorse ? delta < 0 : delta > 0;
    return { key, ...spec, value, baseline: base, delta, worse, better };
  });
}

export interface MetricComparison {
  key: MetricKey;
  label: string;
  unit: string;
  decimals: number;
  a: number;
  b: number;
  difference: number;
  winner: "a" | "b" | "tie";
}

/** Row-by-row comparison. `difference` is B − A. `winner` is the ecologically healthier future. */
export function compareScenarios(a: Scenario, b: Scenario): MetricComparison[] {
  const changesA = changesVsBaseline(a);
  const changesB = changesVsBaseline(b);
  return changesA.map((left, index) => {
    const right = changesB[index];
    const difference = roundTo(right.value - left.value, left.decimals);
    let winner: MetricComparison["winner"] = "tie";
    if (difference !== 0) {
      const bIsHigher = difference > 0;
      const bIsHealthier = left.higherIsWorse ? !bIsHigher : bIsHigher;
      winner = bIsHealthier ? "b" : "a";
    }
    return {
      key: left.key,
      label: left.label,
      unit: left.unit,
      decimals: left.decimals,
      a: left.value,
      b: right.value,
      difference,
      winner,
    };
  });
}

export interface StressPoint {
  year: number;
  stress: number;
}

export function stressTrajectory(pathway: ForecastPathway): StressPoint[] {
  return [
    { year: baseline.year, stress: baseline.ecosystemStress },
    ...FORECAST_YEARS.map((year) => ({
      year,
      stress: getScenario(pathway, year).ecosystemStress,
    })),
  ];
}

export const PATHWAY_COLORS: Record<ForecastPathway, string> = {
  reducing: "#7ee0d6",
  maintaining: "#e4c27a",
  increasing: "#e36a62",
};

export function formatNumber(value: number, decimals: number): string {
  return value.toLocaleString("en-US", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
}

export function formatDelta(delta: number, decimals: number): string {
  const rounded = roundTo(delta, decimals);
  if (rounded === 0) return formatNumber(0, decimals);
  const sign = rounded > 0 ? "+" : "−";
  return sign + formatNumber(Math.abs(rounded), decimals);
}

export function stressColor(value: number): string {
  const t = Math.min(1, Math.max(0, value / 100));
  const green = [61, 190, 139];
  const amber = [228, 194, 122];
  const red = [227, 106, 98];
  const mix = (a: number[], b: number[], u: number) =>
    a.map((channel, index) => Math.round(channel + (b[index] - channel) * u));
  const [r, g, b] = t < 0.5 ? mix(green, amber, t / 0.5) : mix(amber, red, (t - 0.5) / 0.5);
  return `rgb(${r}, ${g}, ${b})`;
}

for (const pathway of FORECAST_PATHWAYS) {
  for (const year of FORECAST_YEARS) {
    getScenario(pathway, year);
  }
}
